//
//  ViewController.swift
//  userdefaults sample1
//
//  Created by adithya on 8/28/18.
//  Copyright © 2018 adithya. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
let defaults = UserDefaults.standard
    @IBOutlet weak var textfield: UITextField!
    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func set(_ sender: Any) {
        defaults.set(textfield.text, forKey: "ourString")
    }
    
    @IBAction func get(_ sender: Any) {
   let ourString = defaults.string(forKey: "ourString")
    label.text = ourString
    }
}

