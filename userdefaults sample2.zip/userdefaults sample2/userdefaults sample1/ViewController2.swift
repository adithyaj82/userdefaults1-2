//
//  ViewController2.swift
//  userdefaults sample1
//
//  Created by adithya on 8/28/18.
//  Copyright © 2018 adithya. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    @IBOutlet weak var label2: UILabel!
    var dataReceivedFromVC1:String!

    @IBOutlet weak var textfield2: UITextField!
    @IBAction func sendToVC1(_ sender: Any) {
     let userDefaults = UserDefaults()
        userDefaults.set(textfield2.text, forKey: "dataReceivedFromVC2")
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
label2.text = dataReceivedFromVC1
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
  

}
